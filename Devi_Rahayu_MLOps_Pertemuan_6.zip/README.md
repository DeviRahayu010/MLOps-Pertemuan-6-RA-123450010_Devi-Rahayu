# Tugas Pertemuan 6 MLOps
## Model Experimentation & Tracking

**Nama:** Devi Rahayu  
**NIM:** 123450010  
**Kelas:** RA

### Tujuan
Melakukan eksperimen model CNN pada dataset Fashion-MNIST,
mencatat parameter dan metrik menggunakan MLflow, melakukan
hyperparameter tuning dengan Optuna, serta mendaftarkan model
dan mencatat dataset menggunakan DVC.

### Tahapan
1. Persiapan dataset Fashion-MNIST.
2. Training baseline CNN dan pencatatan metrik MLflow.
3. Hyperparameter tuning menggunakan Optuna sebanyak 24 trial.
4. Evaluasi konfigurasi terbaik dengan tiga seed.
5. Ablation study.
6. Registrasi model dan pengujian alias champion.
7. Pencatatan dataset menggunakan DVC.

### File
- `data.dvc`: metadata pelacakan dataset menggunakan DVC.
- `experiment_summary.json`: ringkasan hasil eksperimen.
- `requirements.txt`: daftar pustaka yang digunakan.
- Notebook Colab: berisi kode dan output eksperimen.

### Catatan
Hasil yang dicantumkan harus sesuai dengan output eksperimen.
Dataset dan cache DVC disimpan terpisah dari repository kode.
